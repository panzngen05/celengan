const pool = require('../config/db');

// @desc    Make a manual deposit to a target
// @route   POST /api/transactions/deposit
// @access  Private
const makeManualDeposit = async (req, res) => {
    const { target_id, jumlah, deskripsi, payment_gateway_ref } = req.body;
    const user_id = req.user.id;

    if (!target_id || !jumlah || parseFloat(jumlah) <= 0) {
        return res.status(400).json({ message: 'Target ID dan jumlah deposit (positif) diperlukan' });
    }

    const connection = await pool.getConnection(); // Dapatkan koneksi untuk transaksi DB

    try {
        await connection.beginTransaction(); // Mulai transaksi DB

        // 1. Cek apakah target ada dan milik user
        const [targets] = await connection.query(
            'SELECT * FROM targets WHERE id = ? AND user_id = ?',
            [target_id, user_id]
        );

        if (targets.length === 0) {
            await connection.rollback();
            connection.release();
            return res.status(404).json({ message: 'Target not found or not authorized for this user' });
        }
        const target = targets[0];

        if (target.status === 'tercapai') {
             await connection.rollback();
             connection.release();
             return res.status(400).json({ message: 'Target sudah tercapai, tidak bisa deposit lagi.' });
        }


        // **********************************************************************
        // ** TEMPAT INTEGRASI PAYMENT GATEWAY (UNTUK REAL MANUAL DEPOSIT) **
        // Di sini, sebelum mencatat ke DB, Anda akan:
        // 1. Mengirim permintaan ke Payment Gateway (Midtrans, Xendit, dll.)
        //    dengan detail pembayaran.
        // 2. Menunggu callback/response dari Payment Gateway yang menyatakan
        //    pembayaran berhasil.
        // 3. Jika berhasil, baru lanjutkan mencatat transaksi di DB Anda.
        //    Variabel `payment_gateway_ref` akan berisi ID transaksi dari PG.
        //
        // Untuk contoh ini, kita asumsikan pembayaran sudah "berhasil" secara manual.
        // **********************************************************************

        // 2. Tambah jumlah ke `jumlah_terkumpul` di tabel `targets`
        const newJumlahTerkumpul = parseFloat(target.jumlah_terkumpul) + parseFloat(jumlah);
        let newStatus = target.status;

        if (newJumlahTerkumpul >= parseFloat(target.jumlah_target)) {
            // Jika deposit ini membuat target tercapai
            newStatus = 'tercapai';
            // Jika ada kelebihan, bisa dikembalikan atau disimpan sebagai saldo umum (logika tambahan)
            // Untuk saat ini, kita asumsikan jumlah terkumpul tidak melebihi target
            // atau jika melebihi, tetap saja, statusnya tercapai.
            // newJumlahTerkumpul = parseFloat(target.jumlah_target); // Opsional: batasi jumlah terkumpul = jumlah target
        }

        await connection.query(
            'UPDATE targets SET jumlah_terkumpul = ?, status = ? WHERE id = ?',
            [newJumlahTerkumpul, newStatus, target_id]
        );

        // 3. Catat transaksi di tabel `transactions`
        const [result] = await connection.query(
            'INSERT INTO transactions (target_id, user_id, jenis_transaksi, jumlah, deskripsi, payment_gateway_ref) VALUES (?, ?, ?, ?, ?, ?)',
            [target_id, user_id, 'deposit', parseFloat(jumlah), deskripsi || 'Manual deposit', payment_gateway_ref || null]
        );

        await connection.commit(); // Commit transaksi DB jika semua berhasil
        connection.release();

        res.status(201).json({
            message: 'Deposit successful',
            transaction_id: result.insertId,
            target_id,
            new_jumlah_terkumpul: newJumlahTerkumpul,
            target_status: newStatus
        });

    } catch (error) {
        await connection.rollback(); // Rollback jika ada error
        connection.release();
        console.error(error);
        res.status(500).json({ message: 'Server error processing deposit' });
    }
};


// @desc    Get all transactions for a user (bisa difilter)
// @route   GET /api/transactions
// @access  Private
const getUserTransactions = async (req, res) => {
    const user_id = req.user.id;
    const { target_id, jenis_transaksi, start_date, end_date, limit = 10, page = 1 } = req.query;

    let query = 'SELECT t.*, tg.nama_target FROM transactions t JOIN targets tg ON t.target_id = tg.id WHERE t.user_id = ?';
    const queryParams = [user_id];

    if (target_id) {
        query += ' AND t.target_id = ?';
        queryParams.push(target_id);
    }
    if (jenis_transaksi) {
        query += ' AND t.jenis_transaksi = ?';
        queryParams.push(jenis_transaksi);
    }
    if (start_date) {
        query += ' AND DATE(t.tanggal_transaksi) >= ?';
        queryParams.push(start_date);
    }
    if (end_date) {
        query += ' AND DATE(t.tanggal_transaksi) <= ?';
        queryParams.push(end_date);
    }

    query += ' ORDER BY t.tanggal_transaksi DESC';

    const offset = (page - 1) * limit;
    query += ' LIMIT ? OFFSET ?';
    queryParams.push(parseInt(limit), parseInt(offset));


    try {
        const [transactions] = await pool.query(query, queryParams);

        // Query untuk total count (untuk pagination)
        let countQuery = 'SELECT COUNT(*) AS total FROM transactions WHERE user_id = ?';
        const countQueryParams = [user_id];
        // Tambahkan filter yang sama untuk count query jika ada
         if (target_id) { countQuery += ' AND target_id = ?'; countQueryParams.push(target_id); }
         if (jenis_transaksi) { countQuery += ' AND jenis_transaksi = ?'; countQueryParams.push(jenis_transaksi); }
         if (start_date) { countQuery += ' AND DATE(tanggal_transaksi) >= ?'; countQueryParams.push(start_date); }
         if (end_date) { countQuery += ' AND DATE(tanggal_transaksi) <= ?'; countQueryParams.push(end_date); }

        const [totalRows] = await pool.query(countQuery, countQueryParams);
        const total_records = totalRows[0].total;
        const total_pages = Math.ceil(total_records / limit);


        res.json({
            data: transactions,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records,
                total_pages
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error fetching transactions' });
    }
};

// Placeholder untuk Pembayaran Otomatis (SANGAT KOMPLEKS)
// const scheduleAutomaticDeposit = async (req, res) => {
//     // 1. Validasi input (target_id, jumlah, frekuensi, tanggal_mulai, sumber_dana_token)
//     // 2. Simpan jadwal ke database (tabel baru: scheduled_payments)
//     // 3. Setup cron job di server Anda (misalnya node-cron) yang akan:
//     //    a. Mengecek tabel scheduled_payments setiap periode tertentu.
//     //    b. Jika ada jadwal yang jatuh tempo:
//     //       i. Panggil API Payment Gateway untuk melakukan recurring payment menggunakan token sumber dana.
//     //       ii. Jika berhasil, update jumlah_terkumpul di target dan catat transaksi.
//     //       iii. Tangani kegagalan (misalnya, dana tidak cukup, kartu expired).
//     //       iv. Update jadwal untuk pembayaran berikutnya.
//     res.status(510).json({ message: "Fitur pembayaran otomatis belum diimplementasikan. Memerlukan integrasi Payment Gateway dan cron job."})
// }

module.exports = {
    makeManualDeposit,
    getUserTransactions,
    // scheduleAutomaticDeposit // jangan di-export dulu
};
