const express = require('express');
const router = express.Router();
const {
    createTarget,
    getUserTargets,
    getTargetById,
    updateTarget,
    deleteTarget
} = require('../controllers/targetController');
const { protect } = require('../middleware/authMiddleware');

router.route('/')
    .post(protect, createTarget)
    .get(protect, getUserTargets);

router.route('/:id')
    .get(protect, getTargetById)
    .put(protect, updateTarget)
    .delete(protect, deleteTarget);

module.exports = router;
