const express = require('express');
const router = express.Router();
const { makeManualDeposit, getUserTransactions } = require('../controllers/transactionController');
const { protect } = require('../middleware/authMiddleware');

// Semua rute transaksi memerlukan login
router.use(protect);

router.post('/deposit', makeManualDeposit); // Manual deposit
router.get('/', getUserTransactions); // Riwayat transaksi

// Rute untuk pembayaran otomatis bisa ditambahkan di sini nanti
// router.post('/schedule-deposit', scheduleAutomaticDeposit);

module.exports = router;
