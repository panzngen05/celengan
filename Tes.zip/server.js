const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const pool = require('./config/db'); // Impor pool untuk memastikan koneksi dicoba saat start

// Impor Rute
const authRoutes = require('./routes/authRoutes');
const targetRoutes = require('./routes/targetRoutes');
const transactionRoutes = require('./routes/transactionRoutes');

dotenv.config();

const app = express();

// Middleware
app.use(cors()); // Izinkan CORS
app.use(express.json()); // Untuk parsing application/json
app.use(express.urlencoded({ extended: false })); // Untuk parsing application/x-www-form-urlencoded

// Rute Utama
app.get('/', (req, res) => {
    res.send('Selamat Datang di Celengan API!');
});

// Gunakan Rute
app.use('/api/auth', authRoutes);
app.use('/api/targets', targetRoutes);
app.use('/api/transactions', transactionRoutes);

// Error Handling Middleware Sederhana (opsional, bisa dipercanggih)
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something broke!');
});


const PORT = process.env.PORT || 3000;

app.listen(PORT, () => console.log(`Server berjalan di port ${PORT}`));
